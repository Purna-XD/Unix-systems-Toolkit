This textfile guides you to run the mytoolkit and explains its functionalities.

Setup and Instructions:

Just extract the contents from the tar file and run the makefile

Features implemented:

1. mypwd- shows current directory.

2. mycd- changes the directory accordingly.
	mycd ..                 -> goes back to parent directory.
	mycd [folder name]      -> goes to the directory present in current directory.
	mycd [absolute path]    -> goes to the directory to the given path.

3. mytree- shows files and folders in a tree structure.************
	mytree .                -> displays files in tree structure for current directory.
	mytree ..               -> displays files in tree structure for parent directory.
	mytree [absolute path]  -> displays files in tree structure for the given path.

4. myexit- terminates the program/toolkit.

5. mytime- displays the cpu,system and wall time elapsed for the program to run.

6. mymtimes- modified files count is represented as specified.

7. mytimeout- will run the command till the given time is over and exits to the function.

8. The toolkit will exit the program when Ctrl+D is encountered.

9. $ sign with space- mytoolkot when RUN it first displays '$ ' which says its ready to take input from the user.

10. IORedirection- mytoolkit will support IORedirection in both ways '>' and '<'.

11. Pipes- mytoolkit has support for pipe commands also using syntax cmd1|cmd2.

12. All other terminal commands which are present in Unix are implemented.

13. system()- the library routine system() is never used in this program.

//*** []-> this brackets indicate there should be input from the user as specified inside the brackets.
