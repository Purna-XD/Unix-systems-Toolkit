#include<stdio.h> 
#include<string.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<sys/types.h> 
#include<sys/wait.h> 
#include<readline/readline.h> 
#include<readline/history.h>
#include<dirent.h>
#include<fcntl.h>
#include<time.h>
#include<pthread.h>
#include<errno.h>

#define MAXCOM 80 // max number of letters to be supported 
#define MAXLIST 100 // max number of commands to be supported 

#define clear() printf("\033[H\033[J") 

pthread_mutex_t calculating = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t done = PTHREAD_COND_INITIALIZER;

//Input
int takeInput(char* str)
{
	char* buf;
	int i, j = 0;
	char ch[100];
	buf = readline("\n$ ");
	strcpy(ch, buf);
	if (strlen(buf) != 0) {
		add_history(buf);
		strcpy(str, buf);
		for (i = 0; i < strlen(buf); i++)
		{
			if (ch[i] == '>' || ch[i] == '<')
			{
				j = my_io(buf);
				return 1;
			}
		}
		strcpy(str, buf);
		return 0;
	}
	else
	{
		return 1;
	}
}

//Current Directory. 
void printDir()
{
	char cwd[1024];
	getcwd(cwd, sizeof(cwd));
	printf("\nDir: %s\n", cwd);
}


//Exceptions
void execArgs(char** parsed)
{
	pid_t pid = fork();

	if (pid == -1) {
		printf("\nFailed forking child..");
		return;
	}
	else if (pid == 0) {
		if (execvp(parsed[0], parsed) < 0) {
			printf("\nCould not execute command..");
		}
		exit(0);
	}
	else {
		wait(NULL);
		return;
	}
}

//Pipes
void execArgsPiped(char** parsed, char** parsedpipe)
{
	int pipefd[2];
	pid_t p1, p2;
	if (pipe(pipefd) < 0)
	{
		printf("\nPipe could not be initialized");
		return;
	}
	p1 = fork();
	if (p1 < 0)
	{
		printf("\nCould not fork");
		return;
	}

	if (p1 == 0)
	{
		close(pipefd[0]);
		dup2(pipefd[1], STDOUT_FILENO);
		close(pipefd[1]);

		if (execvp(parsed[0], parsed) < 0) {
			printf("\nCould not execute command 1..");
			exit(0);
		}
	}
	else
	{
		p2 = fork();

		if (p2 < 0)
		{
			printf("\nCould not fork");
			return;
		}
		if (p2 == 0)
		{
			close(pipefd[1]);
			dup2(pipefd[0], STDIN_FILENO);
			close(pipefd[0]);
			if (execvp(parsedpipe[0], parsedpipe) < 0)
			{
				printf("\nCould not execute command 2..");
				exit(0);
			}
		}
		else
		{
			wait(NULL);
			wait(NULL);
		}
	}
}

//mypwd
void GetCurrentDirectory(char** parsed)
{
	pid_t p;
	p = fork();
	if (p < 0)
	{
		puts("failed");
	}
	if (p == 0)
	{
		execvp("pwd", parsed);
	}
	else
	{
		wait(NULL);
	}

}

//mytime
void Mytime(char* parsed)

{
	int l = 0;
	clock_t start, end;
	double cpu_time_used;
	start = clock();
	l = ownCmdHandler(parsed);
	end = clock();
	cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;
	printf("%f", cpu_time_used);
	printf("%d", l);
}




//IORedirection
int my_io(char* parsed)
{
	char* terminalInput;
	char str[100], str1[50], str2[50], str3[50], str11[50], str12[50];
	char str_a2[50], str_a3[50];
	int sym_count_g = 0, sym_count_l = 0, i = 0, l1 = 0, l2 = 0, l3 = 0, tt = 0, l11 = 0, l12 = 0, tt1 = 0, big = 0;
	int a2 = 0, a3 = 0;
	int f1, f2;

	terminalInput = parsed;
	strcpy(str, terminalInput);
	str[strlen(str)] = '\0';
	printf("%s \n", str);
	for (i = 0; i < strlen(str); i++)
	{
		if (str[i] == '>')
			sym_count_g++;
		if (str[i] == '<')
			sym_count_l++;

	}
	if ((sym_count_g + sym_count_l) == 1)
	{
		for (i = 0; i < (strlen(str)); i++)
		{

			if ((str[i] == '>') || (str[i] == '<'))
			{
				tt++;
				continue;
			}
			if (tt == 0)
			{
				str1[l1] = str[i];
				l1++;
				if (str[i] == ' ')
				{
					tt1++;
					continue;
				}
				if (tt1 == 0)
				{
					str11[l11] = str[i];
					l11++;
				}
				if (tt1 == 1)
				{
					str12[l12] = str[i];
					l12++;
				}
			}
			if (tt == 1)
			{
				str2[l2] = str[i];
				l2++;
			}
		}
		str1[l1] = '\0'; str2[l2] = '\0'; str12[l12] = '\0'; str11[l11] = '\0';
		printf("%s %s %s\n", str, str1, str2);
		printf("%d %d\n", sym_count_g, sym_count_l);
		if (sym_count_l)
		{
			if (fork() == 0)
			{
				close(0);
				f1 = open(str2, O_RDONLY, 0777);
				if (f1 == -1)
					perror("Error in opening file");
				execlp(str11, str1, NULL);
				exit(0);

			}
		}
		if (sym_count_g)
		{
			if (fork() == 0) {
				close(1);
				f2 = open(str2, O_CREAT | O_WRONLY, 0777);
				if (f2 == -1)
					perror("Error in openeing file");
				execlp(str11, str1, NULL);
				exit(0);
			}
		}
	}
	if ((sym_count_g + sym_count_l) > 1)
	{
		for (i = 0; i < (strlen(str)); i++)
		{
			if ((str[i] == '>') || (str[i] == '<'))
			{
				tt++;
				continue;
			}
			if (tt == 0)
			{
				str1[l1] = str[i];
				l1++;
				if (str[i] == ' ')
				{
					tt1++;
					continue;
				}
				if (tt1 == 0)
				{
					str_a2[a2] = str[i];
					a2++;

				}
				if (tt1 == 1)
				{
					str_a3[a3] = str[i];
					a3++;
				}
			}
			if (tt == 1)
			{
				str2[l2] = str[i];
				l2++;
			}
			if (tt == 2)
			{
				str3[l3] = str[i];
				l3++;
			}
		}
		str1[l1] = '\0'; str2[l2] = '\0'; str3[l3] = '\0'; str_a2[a2] = '\0'; str_a3[a3] = '\0';
		printf("str=%s \n str1=%s \n str2=%s \n str3= %s\n", str, str1, str2, str3);
		printf("%d %d\n", sym_count_g, sym_count_l);
		if (fork() == 0)
		{
			close(0);
			f1 = open(str2, O_RDONLY, 0777);
			if (f1 == -1)
				perror("Error in opening file1");
			close(1);
			f2 = open(str3, O_WRONLY | O_CREAT, 0777);
			if (f2 == -1)
				perror("Error in opening file2");
			execlp(str_a2, str1, NULL);
			exit(0);
		}

	}
	wait(NULL);
	return 1;


}

//tree
void tree(char* basePath, const int root)
{
	int i;
	char path[1000];
	struct dirent* dp;
	DIR* dir = opendir(basePath);

	if (!dir)
		return;

	while ((dp = readdir(dir)) != NULL)
	{
		if (strcmp(dp->d_name, ".") != 0 && strcmp(dp->d_name, "..") != 0)
		{
			for (i = 0; i < root; i++)
			{
				if (i % 2 == 0 || i == 0)
					printf("|");
				else
					printf(" ");

			}
			printf("|_");
			printf("%s\n", dp->d_name);

			strcpy(path, basePath);
			strcat(path, "/");
			strcat(path, dp->d_name);
			tree(path, root + 2);
		}
	}

	closedir(dir);
}

// Function to execute builtin commands 
int ownCmdHandler(char** parsed)
{
	int NoOfOwnCmds = 5, i, switchOwnArg = 0;
	char* ListOfOwnCmds[NoOfOwnCmds];
	char* username;

	ListOfOwnCmds[0] = "myexit";
	ListOfOwnCmds[1] = "mycd";
	ListOfOwnCmds[2] = "mypwd";
	ListOfOwnCmds[3] = "mytree";
	ListOfOwnCmds[4] = "mytime";

	for (i = 0; i < NoOfOwnCmds; i++)
	{
		if (strcmp(parsed[0], ListOfOwnCmds[i]) == 0)
		{
			switchOwnArg = i + 1;
			break;
		}
	}

	switch (switchOwnArg) {
	case 1:
		exit(1);
	case 2:
		chdir(parsed[1]);
		printDir();
		return 1;
	case 3:
		GetCurrentDirectory(parsed);
		return 1;
	case 4:
		tree(parsed[1], 0);
		return 1;
	case 5:
		Mytime(parsed[1]);
		return 1;

//New
		struct timespec max_wait;

		memset(&max_wait, 0, sizeof(max_wait));

		// wait at most 2 seconds //
		max_wait.tv_sec = atoi(parsed[1]);
		Mytimeout(&max_wait,parsed);

//New ends		
		return 1;
	default:
		break;
	}

	return 0;
}

//Pipe or Not
int parsePipe(char* str, char** strpiped)
{
	int i;
	for (i = 0; i < 2; i++) {
		strpiped[i] = strsep(&str, "|");
		if (strpiped[i] == NULL)
			break;
	}

	if (strpiped[1] == NULL)
		return 0;
	else {
		return 1;
	}
}

//Parsing
void parseSpace(char* str, char** parsed)
{
	int i;

	for (i = 0; i < MAXLIST; i++) {
		parsed[i] = strsep(&str, " ");

		if (parsed[i] == NULL)
			break;
		if (strlen(parsed[i]) == 0)
			i--;
	}
}

int processString(char* str, char** parsed, char** parsedpipe)
{

	char* strpiped[2];
	int piped = 0;

	piped = parsePipe(str, strpiped);

	if (piped) {
		parseSpace(strpiped[0], parsed);
		parseSpace(strpiped[1], parsedpipe);

	}
	else {

		parseSpace(str, parsed);
	}

	if (ownCmdHandler(parsed))
		return 0;
	else
		return 1 + piped;
}



int main()
{
	char inputString[MAXCOM], * parsedArgs[MAXLIST];
	char* parsedArgsPiped[MAXLIST];
	int execFlag = 0;
	clear();

	while (1)
	{
		if (takeInput(inputString))
			continue;
		execFlag = processString(inputString,
			parsedArgs, parsedArgsPiped);

		if (execFlag == 1)
			execArgs(parsedArgs);

		if (execFlag == 2)
			execArgsPiped(parsedArgs, parsedArgsPiped);

		//IORedirection
		my_io(inputString);
	}
	return 0;
}
